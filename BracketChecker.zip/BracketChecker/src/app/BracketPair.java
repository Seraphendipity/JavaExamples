package app;

public class BracketPair {
    private String var = "howdy";
    public BracketPair() {
        System.out.println(var);
    }
}